//
//  ALImagePickerController.h
//  Applozic
//
//  Created by devashish on 30/07/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ALImagePickerController : UIImagePickerController

@end
